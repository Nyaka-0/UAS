<?php
session_start();

if (isset($_POST['username']) && isset($_POST['password'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Connect to the database
    $db = new mysqli('localhost', 'username', 'password', 'database');

    if ($db->connect_error) {
