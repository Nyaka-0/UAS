<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign-In</title>
    <link rel="stylesheet" href="registration_style.css">
</head>
<body>
    <main>
        <h2>Sign-In Nayaka Online Bookstore</h2>
        <div class="container">
            <?php
            if (isset($_POST["submit"])) {
                $fullName = $POST["fullname"];
                $email = $POST["email"];
                $password = $POST["password"];
                $passwordRepeat = $POST["repeat_password"];

                $passwordHash = password_hash($password, PASSWORD_DEFAULT);

                $errors = array();

                if (empty($fullName) OR empty($email) OR empty($passwordRepeat)) {
                 array_push($errors,"Butuh semua untuk diisisih");
                }

                if (!filter_var($email, FILTER_VALIDATE)) {
                 array_push($errors,"Email Needed");
                }
               }else{
                require_once "koneksi.php";
                $sql = "INSERT INTO users (full_name, email, password) VALUES ( ?, ?, ?)";
                $stmt = mysqli_stmt_init($koneksi);
                $prepareStmt = mysqli_stmt_prepare($stmt,$sql);
                if ($prepareStmt)
                    mysqli_stmt_bind_param($stmt,"sss", $fullName, $email, $passwordHash);
                    echo "<div class='success'>Success</div>";
               }
            ?>

            <form action="registration.php" method="post">
                <div class=="form-group">
                    <input type="text" class="form-control" name="fullname" placeholder="full name :">
                </div>
                <div class=="form-group">
                    <input type="email" class="form-control" name="email" placeholder="Email :">
                </div>
                <div class=="form-group">
                    <input type="password" class="form-control" name="password" placeholder="Password :">
                </div>
                <div class=="form-group">
                    <input type="text" class="form-control" name="repeat_password" placeholder="Repeat Password :">
                </div>
                <div class=="form-btn">
                    <input type="submit" class="btn btn-primary" name="register" placeholder="Sumbmit">
                </div>
            </form>
            <a href="login.php" >If you don't have an account click this to sign up</a>
        </div>
    </main>

    <footer>
        <div class="container">
            <p>&copy; 2024 Nayaka Online Bookstore</p>
            <ul>
                <p><a href="#">Terms of Use</a></p>
                <p><a href="#">Privacy Policy</a></p>
            </ul>
        </div>
    </footer>
</body>
</html>
