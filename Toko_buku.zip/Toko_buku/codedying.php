<?php

require_once 'koneksi.php';
$query = "SELECT id_pesanan, tanggal_pesanan, id_pembeli, nama_pembeli, id_barang, nama_barang, jumlah_pesanan FROM cod";
$result = mysqli_query($koneksi, $query);

echo "<table border='1'>
        <tr>
            <th>ID pesanan</th>
            <th>Tanggal Pesanan</th>
            <th>ID Pembeli</th>
            <th>Nama Pembeli</th>
            <th>ID Barang</th>
            <th>Nama Barang</th>
            <th>Jumlah Pesanan</th>
        </tr>
";

while ($row = mysqli_fetch_assoc($result)) {
    echo "<tr>
            <td>" . $row['id_pesanan'] . "</td>
            <td>" . $row['tanggal_pesanan'] . "</td>
            <td>" . $row['id_pembeli'] . "</td>
            <td>" . $row['nama_pembeli'] . "</td>
            <td>" . $row['id_barang'] . "</td>
            <td>" . $row['nama_barang'] . "</td>
            <td>" . $row['jumlah_pesanan'] . "</td>
        </tr>";
}

echo "</table>";

mysqli_close($koneksi);

?>